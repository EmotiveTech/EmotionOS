cd kernel/
make run
cd ..