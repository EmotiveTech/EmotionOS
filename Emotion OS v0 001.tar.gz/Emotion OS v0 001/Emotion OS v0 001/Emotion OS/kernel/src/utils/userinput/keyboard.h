#pragma once
#include <stdint.h>
#include "kbScancodeConverter.h"
#include "../BasicRenderer.h"

void HandleKeyboard(uint8_t scancode);