#include "BasicRenderer.h"
#include "WindowManager.h"
#include "Framebuffer.h"
#include <stdint.h>
#include <cstdlib>
#include "memory.h"
#include "cstr.h"
#include "random.h"
#include "debug/Stack.h"

#define CHECK_BIT(var, pos) ((var) & (1 << (pos)))

BasicRenderer *GlobalRenderer;

BasicRenderer::BasicRenderer(Framebuffer *targetFramebuffer, PSF1_FONT *psf1_Font)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    TargetFramebuffer = targetFramebuffer;
    PSF1_Font = psf1_Font;
    Color = 0xffffffff;
    ClearColor = 0xff000000;
    CursorPosition = {0, 0};
    //GlobalStack.Pop("BasicRenderer::BasicRenderer");
}

void BasicRenderer::PutPix(uint32_t x, uint32_t y, uint32_t colour)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    if (!(x >= TargetFramebuffer->Width || y >= TargetFramebuffer->Height))
    {
        *(uint32_t *)((uint64_t)TargetFramebuffer->BaseAddress + (x * 4) + (y * TargetFramebuffer->PixelsPerScanLine * 4)) = colour;
    }
    //GlobalStack.Pop("BasicRenderer::PutPix");
}

uint32_t BasicRenderer::GetPix(uint32_t x, uint32_t y)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);

    uint32_t toReturn = *(uint32_t *)((uint64_t)TargetFramebuffer->BaseAddress + (x * 4) + (y * TargetFramebuffer->PixelsPerScanLine * 4));

    //GlobalStack.Pop("BasicRenderer::GetPix");
    return toReturn;
}

void BasicRenderer::RandomChar()
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    for (uint64_t i1 = 0; i1 < TargetFramebuffer->Height; i1 += 8)
    {
        CursorPosition.Y = i1;
        for (uint64_t i = 0; i < TargetFramebuffer->Width; i += 16)
        {
            /* code */
            int64_t randNum = 1; // (rand()%(9-0 + 1) + 0)
            CursorPosition.X = i;
            PutChar(*(char*)to_string(randNum));
        }
    }
    //GlobalStack.Pop("BasicRenderer::RandomChar");
}

void BasicRenderer::ClearMouseCursor(uint8_t *MouseCursor, Point position, uint32_t *ColorPallete, uint8_t ColorPalleteLength)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    if (!MouseDrawn) {
        //GlobalStack.Pop("BasicRenderer::ClearMouseCursor");
        return;
    }


    int xMax = 16;
    int yMax = 16;
    // int differenceX = TargetFramebuffer->Width - position.X;
    // int differenceY = TargetFramebuffer->Height - position.Y;

    // if (differenceX < 16)
    //     xMax = differenceX;
    // if (differenceY < 16)
    //     yMax = differenceY;

    for (int y = 0; y < yMax; y++)
    {
        for (int x = 0; x < xMax; x++)
        {
            // int bit = y * 16 + x;
            // int byte = bit / 8;
            // if ((MouseCursor[byte] & (0b10000000 >> (x % 8))))
            // {

            //     // if (GetPix(position.X + x, position.Y + y) == MouseCursorBufferAfter[x + y * 16])
            //     // {
            //         //PutPix(position.X + x, position.Y + y, MouseCursorBuffer[x + y * 16]);
            //     //}
            // }
            for (uint8_t i = 0; i < ColorPalleteLength; i++)
            {
                if (MouseDrawn && MouseCursorBufferAfter[x + y * 16] == ColorPallete[i])
                    PutPix(position.X + x, position.Y + y, MouseCursorBuffer[x + y * 16]);
            }
        }
    }

    //GlobalStack.Pop("BasicRenderer::ClearMouseCursor");
}

void BasicRenderer::Draw16b(uint16_t *map, Point position, uint32_t color, uint32_t otherColor)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    int xMax = 32;
    int yMax = 32;
    int differenceX = TargetFramebuffer->Width - position.X;
    int differenceY = TargetFramebuffer->Height - position.Y;

    if (differenceX < 32)
        xMax = differenceX;
    if (differenceY < 32)
        yMax = differenceY;

    for (int y = 0; y < yMax; y++)
    {
        for (int x = 0; x < xMax; x++)
        {
            int bit = y * 32 + x;
            int byte = bit / 16;
            if ((map[byte] & (0b1000000000000000 >> (x % 16))))
            {
                PutPix(position.X + x, position.Y + y, color);
            }
            else
            {
                PutPix(position.X + x, position.Y + y, otherColor);
            }
        }
    }

    MouseDrawn = true;
    //GlobalStack.Pop("BasicRenderer::Draw16b");
}

void BasicRenderer::DrawHex(uint32_t *map, Point position, uint16_t dimensions)
{ // hex
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    int y = position.Y;
    int x = position.X;
    for (int i = 0; i < dimensions * dimensions; i++)
    {
        if (i % dimensions == 0)
        {
            // x is a multiple of 32
            y++;
            x = position.X;
        }
        else
        {
            x++;
        }
        // Print(to_hstring(map[i]));
        if (map[i] != 0x00000000)
        {
            PutPix(x, y, map[i]); // map[i] ||
        }
    }
    //GlobalStack.Pop("BasicRenderer::DrawHex");
}

void BasicRenderer::DrawOverlayMouseCursor(uint8_t *MouseCursor, Point position, uint32_t color)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    int xMax = 16;
    int yMax = 16;
    int differenceX = TargetFramebuffer->Width - position.X;
    int differenceY = TargetFramebuffer->Height - position.Y;

    if (differenceX < 16)
        xMax = differenceX;
    if (differenceY < 16)
        yMax = differenceY;

    for (int y = 0; y < yMax; y++)
    {
        for (int x = 0; x < xMax; x++)
        {
            int bit = y * 16 + x;
            int byte = bit / 8;
            if ((MouseCursor[byte] & (0b10000000 >> (x % 8))))
            {

                MouseCursorBuffer[x + y * 16] = GetPix(position.X + x, position.Y + y);
                PutPix(position.X + x, position.Y + y, color);
                MouseCursorBufferAfter[x + y * 16] = GetPix(position.X + x, position.Y + y);
            }
        }
    }

    MouseDrawn = true;
    //GlobalStack.Pop("BasicRenderer::DrawOverlayMouseCursor");
}

void BasicRenderer::DrawMouseHex(uint32_t *MouseCursor, Point position)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    int xMax = 16;
    int yMax = 16;
    int differenceX = TargetFramebuffer->Width - position.X;
    int differenceY = TargetFramebuffer->Height - position.Y;

    if (differenceX < 16)
        xMax = differenceX;
    if (differenceY < 16)
        yMax = differenceY;

    for (int y = 0; y < yMax; y++)
    {
        for (int x = 0; x < xMax; x++)
        {
            MouseCursorBuffer[x + y * 16] = GetPix(position.X + x, position.Y + y);
        }
    }

    DrawHex(MouseCursor, position, 16);

    for (int y = 0; y < yMax; y++)
    {
        for (int x = 0; x < xMax; x++)
        {
            MouseCursorBufferAfter[x + y * 16] = GetPix(position.X + x, position.Y + y);
        }
    }

    MouseDrawn = true;
    //GlobalStack.Pop("BasicRenderer::DrawMouseHex");
}

void BasicRenderer::Clear()
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    uint64_t fbBase = (uint64_t)TargetFramebuffer->BaseAddress;
    uint64_t bytesPerScanline = TargetFramebuffer->PixelsPerScanLine * 4;
    uint64_t fbHeight = TargetFramebuffer->Height;
    uint64_t fbSize = TargetFramebuffer->BufferSize;

    for (int verticalScanline = 0; verticalScanline < fbHeight; verticalScanline++)
    {
        uint64_t pixPtrBase = fbBase + (bytesPerScanline * verticalScanline);
        for (uint32_t *pixPtr = (uint32_t *)pixPtrBase; pixPtr < (uint32_t *)(pixPtrBase + bytesPerScanline); pixPtr++)
        {
            *pixPtr = ClearColor;
        }
    }

    //GlobalWM->RenderTaskbar(0xffffffff, 0xff000000, 32);
    //GlobalWM->RedrawWindows();

    //GlobalStack.Pop("BasicRenderer::Clear");
}

void BasicRenderer::ClearChar()
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    if (CursorPosition.X == 0)
    {
        CursorPosition.X = TargetFramebuffer->Width;
        CursorPosition.Y -= 16;
        if (CursorPosition.Y < 0)
            CursorPosition.Y = 0;
    }

    unsigned int xOff = CursorPosition.X;
    unsigned int yOff = CursorPosition.Y;

    unsigned int *pixPtr = (unsigned int *)TargetFramebuffer->BaseAddress;
    for (unsigned long y = yOff; y < yOff + 16; y++)
    {
        for (unsigned long x = xOff - 8; x < xOff; x++)
        {
            *(unsigned int *)(pixPtr + x + (y * TargetFramebuffer->PixelsPerScanLine)) = ClearColor;
        }
    }

    CursorPosition.X -= 8;

    if (CursorPosition.X < 0)
    {
        CursorPosition.X = TargetFramebuffer->Width;
        CursorPosition.Y -= 16;
        if (CursorPosition.Y < 0)
            CursorPosition.Y = 0;
    }

    //GlobalStack.Pop("BasicRenderer::ClearChar");
}

void BasicRenderer::Fill(uint32_t color)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    uint64_t fbBase = (uint64_t)TargetFramebuffer->BaseAddress;
    uint64_t bytesPerScanline = TargetFramebuffer->PixelsPerScanLine * 4;
    uint64_t fbHeight = TargetFramebuffer->Height;
    uint64_t fbSize = TargetFramebuffer->BufferSize;

    for (int verticalScanline = 0; verticalScanline < fbHeight; verticalScanline++)
    {
        uint64_t pixPtrBase = fbBase + (bytesPerScanline * verticalScanline);
        for (uint32_t *pixPtr = (uint32_t *)pixPtrBase; pixPtr < (uint32_t *)(pixPtrBase + bytesPerScanline); pixPtr++)
        {
            *pixPtr = color;
        }
    }

    //GlobalStack.Pop("BasicRenderer::Fill");
}

void BasicRenderer::FillWithNoise()
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    uint64_t fbBase = (uint64_t)TargetFramebuffer->BaseAddress;
    uint64_t bytesPerScanline = TargetFramebuffer->PixelsPerScanLine * 4;
    uint64_t fbHeight = TargetFramebuffer->Height;
    uint64_t fbSize = TargetFramebuffer->BufferSize;

    for (int verticalScanline = 0; verticalScanline < fbHeight; verticalScanline++)
    {
        uint64_t pixPtrBase = fbBase + (bytesPerScanline * verticalScanline);
        for (uint32_t *pixPtr = (uint32_t *)pixPtrBase; pixPtr < (uint32_t *)(pixPtrBase + bytesPerScanline); pixPtr++)
        {
            *pixPtr = random_r();
        }
    }

    //GlobalStack.Pop("BasicRenderer::FillWithNoise");
}

void BasicRenderer::Next()
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    CursorPosition.X = 0;
    CursorPosition.Y += 16;
    //GlobalStack.Pop("BasicRenderer::Next");
}

/*void BasicRenderer::PrintMany(char* strings[], uint8_t length)
{

   for( uint8_t i = 0; i < length - 1; i++ ) {
      Print(strings[i]);
   }

}*/

void BasicRenderer::PrintNL(const char *str)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    Point startCursorPos = CursorPosition;
    char *chr = (char *)str;
    while (*chr != 0)
    {
        PutChar(*chr, CursorPosition.X, CursorPosition.Y);
        CursorPosition.X += 8;
        if (CursorPosition.X + 8 > TargetFramebuffer->Width)
        {
            CursorPosition.X = 0;
            CursorPosition.Y += 16;
        }
        chr++;
    }
    CursorPosition.X = startCursorPos.X;
    CursorPosition.Y = startCursorPos.Y + 16;
    //GlobalStack.Pop("BasicRenderer::PrintNL");
}

void BasicRenderer::Print(const char *str)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    char *chr = (char *)str;
    while (*chr != 0)
    {
        PutChar(*chr, CursorPosition.X, CursorPosition.Y);
        CursorPosition.X += 8;
        if (CursorPosition.X + 8 > TargetFramebuffer->Width)
        {
            CursorPosition.X = 0;
            CursorPosition.Y += 16;
        }
        chr++;
    }
    //GlobalStack.Pop("BasicRenderer::Print");
}

void BasicRenderer::PutChar(char chr, unsigned int xOff, unsigned int yOff)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    unsigned int *pixPtr = (unsigned int *)TargetFramebuffer->BaseAddress;
    char *fontPtr = (char *)PSF1_Font->glyphBuffer + (chr * PSF1_Font->psf1_Header->charsize);
    for (unsigned long y = yOff; y < yOff + 16; y++)
    {
        for (unsigned long x = xOff; x < xOff + 8; x++)
        {
            if ((*fontPtr & (0b10000000 >> (x - xOff))) > 0)
            {
                PutPix(x, y, Color);
                //*(unsigned int *)(pixPtr + x + (y * TargetFramebuffer->PixelsPerScanLine)) = Color;
            }
        }
        fontPtr++;
    }
    //GlobalStack.Pop("BasicRenderer::PutChar");
}

void BasicRenderer::PutChar(char chr)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    PutChar(chr, CursorPosition.X, CursorPosition.Y);
    CursorPosition.X += 8;
    if (CursorPosition.X + 8 > TargetFramebuffer->Width)
    {
        CursorPosition.X = 0;
        CursorPosition.Y += 16;
    }
    //GlobalStack.Pop("BasicRenderer::PutChar");
}


void BasicRenderer::PanicFill(uint32_t color)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    uint64_t fbBase = (uint64_t)TargetFramebuffer->BaseAddress;
    uint64_t bytesPerScanline = TargetFramebuffer->PixelsPerScanLine * 4;
    uint64_t fbHeight = TargetFramebuffer->Height;
    uint64_t fbSize = TargetFramebuffer->BufferSize;

    for (int verticalScanline = 0; verticalScanline < fbHeight; verticalScanline++)
    {
        if(verticalScanline % 8 != 0) continue;
        uint64_t pixPtrBase = fbBase + (bytesPerScanline * verticalScanline);
        for (uint32_t *pixPtr = (uint32_t *)pixPtrBase; pixPtr < (uint32_t *)(pixPtrBase + bytesPerScanline); pixPtr++)
        {
            *pixPtr = color;
        }
    }

    //GlobalStack.Pop("BasicRenderer::Fill");
}
