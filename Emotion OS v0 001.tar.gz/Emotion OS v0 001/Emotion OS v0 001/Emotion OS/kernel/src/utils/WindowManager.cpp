#include "WindowManager.h"
#include "BasicRenderer.h"
#include "ColorMaps.h"
#include "random.h"


//BasicRenderer *GlobalRenderer;

void WindowManager::NewWindow(uint32_t x, uint32_t y, uint32_t color, uint32_t textColor, uint32_t width, uint32_t height, char *title)
{
    for (uint32_t i = x; i <= x + width; i++)
    {
        for (uint32_t i2 = y; i2 <= y + height; i2++)
        {
            if ((i2 >= y && i2 <= y + 30) || (i2 == y || i == x) || (i == x + width || i2 == y + height))
            {
                GlobalRenderer->PutPix(i, i2, 0xffffffff);
            }
            else
            {
                GlobalRenderer->PutPix(i, i2, color);
            }
        }
    }

    // set all old values
    Point OldCursorPos = GlobalRenderer->CursorPosition;
    uint32_t OldColor = GlobalRenderer->Color;

    // set current values
    GlobalRenderer->CursorPosition.X = x + 10;
    GlobalRenderer->CursorPosition.Y = y + 10;
    GlobalRenderer->Color = textColor;

    // print
    GlobalRenderer->Print(title);

    // revert all changed values
    GlobalRenderer->Color = OldColor;
    GlobalRenderer->CursorPosition = OldCursorPos;

    Window newWindow = {x,y,width,height,color,textColor,title};
    
    // newWindow.x = x;
    // newWindow.y = y;
    // newWindow.width = width;
    // newWindow.height = height;
    // newWindow.color = color;
    // newWindow.textColor = textColor;
    // newWindow.title = title;

    //windows[windowCount] = newWindow; // fix this i fucking swear to god
    if(windowCount != 0) windowCount++;
}


void WindowManager::DrawWindow(uint32_t x, uint32_t y, uint32_t color, uint32_t textColor, uint32_t width, uint32_t height, char *title)
{
    for (uint32_t i = x; i <= x + width; i++)
    {
        for (uint32_t i2 = y; i2 <= y + height; i2++)
        {
            if ((i2 >= y && i2 <= y + 30) || (i2 == y || i == x) || (i == x + width || i2 == y + height))
            {
                GlobalRenderer->PutPix(i, i2, 0xffffffff);
            }
            else
            {
                GlobalRenderer->PutPix(i, i2, color);
            }
        }
    }

    // set all old values
    Point OldCursorPos = GlobalRenderer->CursorPosition;
    uint32_t OldColor = GlobalRenderer->Color;

    // set current values
    GlobalRenderer->CursorPosition.X = x + 10;
    GlobalRenderer->CursorPosition.Y = y + 10;
    GlobalRenderer->Color = textColor;

    // print
    GlobalRenderer->Print(title);

    // revert all changed values
    GlobalRenderer->Color = OldColor;
    GlobalRenderer->CursorPosition = OldCursorPos;
}

void WindowManager::RedrawWindows()
{
    for (uint32_t i = windowCount; i < windowCount; i++)
    {
        Window w = windows[windowCount];
        DrawWindow(
            w.x,
            w.y,
            w.color,
            w.textColor,
            w.width,
            w.height,
            w.title
            );
    }
}

void WindowManager::RenderTaskbar(uint32_t color, uint32_t textColor, uint32_t height)
{
    uint32_t y = GlobalRenderer->TargetFramebuffer->Height - height;

    for (uint32_t i = 0; i <= GlobalRenderer->TargetFramebuffer->Width; i++)
    {
        for (uint32_t i2 = y; i2 <= y + height; i2++)
        {
            GlobalRenderer->PutPix(i, i2, color);
        }
    }

    GlobalRenderer->Draw16b(ColorMaps::LogoBit, {0, y}, 0xff000000, 0xffffffff);
    // // set all old values
    // Point OldCursorPos = GlobalRenderer->CursorPosition;
    // uint32_t OldColor = GlobalRenderer->Color;

    // // set current values
    // GlobalRenderer->CursorPosition.X = 10;
    // GlobalRenderer->CursorPosition.Y = y + 10;
    // GlobalRenderer->Color = textColor;

    // // print
    // GlobalRenderer->Print("InsideOut-OS");

    // // revert all changed values
    // GlobalRenderer->Color = OldColor;
    // GlobalRenderer->CursorPosition = OldCursorPos;

}