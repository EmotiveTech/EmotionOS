int random_r();
void srandom_r(unsigned int seed);
