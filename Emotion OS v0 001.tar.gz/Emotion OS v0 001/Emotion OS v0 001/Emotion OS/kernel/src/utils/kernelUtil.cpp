#include "kernelUtil.h"
#include "gdt/gdt.h"
#include "interrupts/IDT.h"
#include "interrupts/interrupts.h"
#include "IO.h"
#include "memory/heap.h"
#include "cstr.h"
#include "panic.h"
#include "scheduling/pit/pit.h"
#include "debug/Stack.h"
#include "InitInfo.h"

void PrepareACPI(BootInfo *bootInfo)
{
    GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    ACPI::SDTHeader *xsdt = (ACPI::SDTHeader *)(bootInfo->rsdp->XSDTAddress);

    ACPI::MCFGHeader *mcfg = (ACPI::MCFGHeader *)ACPI::FindTable(xsdt, (char *)"MCFG");

    PCI::EnumeratePCI(mcfg);
    GlobalStack.Pop();
}

KernelInfo kernelInfo;

void PrepareMemory(BootInfo *bootInfo)
{
    GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    uint64_t mMapEntries = bootInfo->mMapSize / bootInfo->mMapDescSize;
    //GlobalRenderer->PrintNL("PrepareMemory: defined map entries");
    //GlobalRenderer->PrintNL("PrepareMemory: preparing GlobalAllocator");
    GlobalAllocator = PageFrameAllocator();
    //GlobalRenderer->PrintNL("PrepareMemory: initialized GlobalAllocator, reading EFI memory map...");
    GlobalAllocator.ReadEFIMemoryMap(bootInfo->mMap, bootInfo->mMapSize, bootInfo->mMapDescSize);
    //GlobalRenderer->PrintNL("PrepareMemory: EFI memory map read success");

    uint64_t kernelSize = (uint64_t)&_KernelEnd - (uint64_t)&_KernelStart;
    //GlobalRenderer->PrintNL("PrepareMemory: defined kernel size");
    uint64_t kernelPages = (uint64_t)kernelSize / 4096 + 1;
    //GlobalRenderer->PrintNL("PrepareMemory: defined kernel pages");

    //GlobalRenderer->PrintNL("PrepareMemory: locking pages of kernel mem!");
    GlobalAllocator.LockPages(&_KernelStart, kernelPages);
    //GlobalRenderer->PrintNL("PrepareMemory: lock success");

    //GlobalRenderer->PrintNL("PrepareMemory: req pages");
    PageTable *PML4 = (PageTable *)GlobalAllocator.RequestPage();
    //GlobalRenderer->PrintNL("PrepareMemory: memset");
    memset(PML4, 0, 0x1000);

    //GlobalRenderer->PrintNL("PrepareMemory: init page table manager");
    GlobalPTM = PageTableManager(PML4);
    //GlobalRenderer->PrintNL("PrepareMemory: init page table manager SUCCESS");

    uint64_t memSize = GetMemorySize(bootInfo->mMap, mMapEntries, bootInfo->mMapDescSize);

    //GlobalRenderer->Print("PrepareMemory: memsize:");
    //GlobalRenderer->PrintNL(to_string(memSize));
    //GlobalRenderer->CursorPosition.X = 0;
    //GlobalRenderer->PrintNL("PrepareMemory: memory map loop start!");

    //GlobalRenderer->CursorPosition.Y = 300;
    //GlobalRenderer->Print("L="); // left
    //long originalY = GlobalRenderer->CursorPosition.Y;
    // double percentThresholdToPrint = 0.98;
    //

    for (uint64_t t = 0; t < memSize; t += 0x1000)
    {
        // double percentThere = (double)t / (double)memSize;
        // if (percentThere >= percentThresholdToPrint)
        // {
        //     GlobalRenderer->CursorPosition.X = 8 * 3;
        //     GlobalRenderer->CursorPosition.Y = originalY;

        //     uint32_t y = originalY;

        //     for (uint32_t i = 8 * 3; i <= 8 * 3 + 128; i++)
        //     {
        //         for (uint32_t i2 = y; i2 <= y + 16*2; i2++)
        //         {
        //             //GlobalRenderer->PutPix(i, i2, 0xff000000);
        //         }
        //     }

        //     // GlobalRenderer->Fill(0xff111111);
        //     GlobalRenderer->PrintNL(to_string(memSize-t));

        //     GlobalRenderer->CursorPosition.X = 8 * 3;
        //     GlobalRenderer->CursorPosition.Y = originalY + 16;
        //     GlobalRenderer->Print("A");
        // }

        //if(memSize-t == 0x1000) continue;
        GlobalPTM.MapMemory((void *)t, (void *)t);
        // if (percentThere >= percentThresholdToPrint) {
        //     GlobalRenderer->Print("B");
        // }
    }


    //GlobalRenderer->PrintNL("PrepareMemory: memory map loop finish!");

    uint64_t fbBase = (uint64_t)bootInfo->framebuffer->BaseAddress;
    //GlobalRenderer->PrintNL("PrepareMemory: defined framebuffer address");
    uint64_t fbSize = (uint64_t)bootInfo->framebuffer->BufferSize + 0x1000;
    //GlobalRenderer->PrintNL("PrepareMemory: defined framebuffer size, locking pages");
    GlobalAllocator.LockPages((void *)fbBase, fbSize / 0x1000 + 1);
    //GlobalRenderer->PrintNL("PrepareMemory: pages locked!");


    //GlobalRenderer->PrintNL("PrepareMemory: running obscure memory map loop...");
    for (uint64_t t = fbBase; t < fbBase + fbSize; t += 4096)
    {
        GlobalPTM.MapMemory((void *)t, (void *)t);
    }


    //GlobalRenderer->PrintNL("PrepareMemory: obscure memory map loop finish!");

    //GlobalRenderer->PrintNL("PrepareMemory: running obscure assembly...");
    asm("mov %0, %%cr3" : : "r"(PML4));

    //GlobalRenderer->PrintNL("PrepareMemory: asm success");

    //GlobalRenderer->PrintNL("PrepareMemory: defining global page table manager..");
    kernelInfo.pageTableManager = &GlobalPTM;

    //while(true) {};
    //GlobalRenderer->PrintNL("PrepareMemory: ALL SUCCESS!!!");

    GlobalStack.Pop();
}

IDTR idtr;
void SetIDTGate(void *handler, uint8_t entryOffset, uint8_t type_attr, uint8_t selector)
{
    GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    IDTDescEntry *interrupt = (IDTDescEntry *)(idtr.Offset + entryOffset * sizeof(IDTDescEntry));
    interrupt->SetOffset((uint64_t)handler);
    interrupt->type_attr = type_attr;
    interrupt->selector = selector;
    GlobalStack.Pop();
}

void PrepareInterrupts()
{
    GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    idtr.Limit = 0x0FFF;
    idtr.Offset = (uint64_t)GlobalAllocator.RequestPage();

    SetIDTGate((void *)PageFault_Handler, 0xE, IDT_TA_InterruptGate, 0x08);
    SetIDTGate((void *)DoubleFault_Handler, 0x8, IDT_TA_InterruptGate, 0x08);
    SetIDTGate((void *)GPFault_Handler, 0xD, IDT_TA_InterruptGate, 0x08);
    SetIDTGate((void *)KeyboardInt_Handler, 0x21, IDT_TA_InterruptGate, 0x08);
    SetIDTGate((void *)MouseInt_Handler, 0x2C, IDT_TA_InterruptGate, 0x08);
    SetIDTGate((void *)PITInt_Handler, 0x20, IDT_TA_InterruptGate, 0x08);

    asm("lidt %0" : : "m"(idtr));

    RemapPIC(); // for interrupts and devices
    GlobalStack.Pop();
}

BasicRenderer r = BasicRenderer(NULL, NULL);
PanicScreen p = PanicScreen();
KernelInfo InitializeKernel(BootInfo *bootInfo)
{
    //GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
    // set literally one pixel to whatever color this is
    //*(uint32_t *)((uint64_t)bootInfo->framebuffer->BaseAddress + (32 * 4) + (32 * bootInfo->framebuffer->PixelsPerScanLine * 4)) = 0xffff0000;

    //GlobalRenderer->PrintNL("InitializeKernel: INIT + BASIC RENDERER");
    //GlobalRenderer->PrintNL("InitializeKernel: preparing memory...");

    GDTDescriptor gdtDescriptor;
    gdtDescriptor.Size = sizeof(GDT) - 1;
    gdtDescriptor.Offset = (uint64_t)&DefaultGDT;

    LoadGDT(&gdtDescriptor);

    //GlobalRenderer->PrintNL("PLEASSEEEE WORK!!!");



    PrepareMemory(bootInfo);



    r = BasicRenderer(bootInfo->framebuffer, bootInfo->psf1_Font);
    GlobalRenderer = &r;

    GlobalPanic = &p;

    GlobalInitInfo.BasicRendererInitialized = true;


    //GlobalRenderer->Fill(0xffff0000);

    // GlobalRenderer->PrintNL("InitializeKernel: memset!!!!!!!!!!");
    PrepareInterrupts();


    //memset(bootInfo->framebuffer->BaseAddress, 0xaa, bootInfo->framebuffer->BufferSize);
    // asm volatile ("cli"); // disable all interrupts
    // while(true) {
    //     asm volatile ("hlt"); // and HALT!
    // }



    GlobalRenderer->PrintNL("InitializeKernel: AAAAAAAAAAAAAAAA");

    //memset(bootInfo->framebuffer->BaseAddress, 0, bootInfo->framebuffer->BufferSize);
    GlobalRenderer->PrintNL("InitializeKernel: memory and interrupts ready");


    GlobalRenderer->PrintNL("InitializeKernel: setting up heap now...");

    InitializeHeap((void *)0x0000100000000000, 0x10); // old: 0x10
    // // heap addr default: 0x0000100000000000

    GlobalRenderer->PrintNL("InitializeKernel: heap ready");

    GlobalInitInfo.MemoryInitialized = true;

    InitPS2Mouse();
    GlobalRenderer->PrintNL("InitializeKernel: PS2 mouse ready");
    // GlobalRenderer->PrintNL("InitializeKernel: mouse ready");
    //PrepareACPI(bootInfo);
    GlobalRenderer->PrintNL("InitializeKernel: ACPI OK");
    //    while(true) {};
    // GlobalRenderer->PrintNL("InitializeKernel: ACPI ready!");
    outb(PIC1_DATA, 0b11111000);
    outb(PIC2_DATA, 0b11101111);

    asm("sti"); // cli for disabling interrupts, sti for enabling them

    // GlobalRenderer->Clear();

    GlobalRenderer->PrintNL("InitializeKernel: all ready, returning kernel info");

    GlobalInitInfo.KernelInitialized = true;
    //GlobalStack.Pop("InitializeKernel");
    return kernelInfo;
}
