#include "stdint.h"
#pragma once

#define STRINGIFY(x) #x
class Stack
{
public:
    void Push(const char *functionName, uint64_t line);
    void Pop();

    void Dump();


private:
    int n = 128;
    int top = 0;

    const char *stack[128] = {};
    const char *desperateStack;
};

extern Stack GlobalStack;
