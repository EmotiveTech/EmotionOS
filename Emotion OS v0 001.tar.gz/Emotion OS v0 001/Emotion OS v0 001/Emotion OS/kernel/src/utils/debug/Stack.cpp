#include "Stack.h"
#include "../BasicRenderer.h"
#include "../panic.h"
#include "../cstr.h"
#include "../InitInfo.h"

void Stack::Push(const char *functionName, uint64_t line)
{
    //GlobalRenderer->PrintNL(functionName);

    if (GlobalInitInfo.MemoryInitialized == false) return;

    //if (top >= n - 1)
    //    return; //GlobalPanic->init("Stack overflow");
    stack[top++] = functionName;

    //if(functionName[0] == 'B' || !GlobalInitInfo.MemoryInitialized || GlobalPanic->PanicEnabled) return;

    // GlobalRenderer->Print(functionName);
    // GlobalRenderer->Print(" on line ");
    // GlobalRenderer->PrintNL(to_string(line));

    //desperateStack = functionName;
}

void Stack::Pop()
{
    if (top <= 0)
        return; //GlobalPanic->init("Stack underflow");
    top--;
}

void Stack::Dump() {
    // GlobalRenderer->PrintNL("DESPERATE STACK:");
    // if(desperateStack) {
    //     GlobalRenderer->Print(desperateStack);
    // } else {
    //     GlobalRenderer->Print("no stack found");
    // }

    long originX = GlobalRenderer->CursorPosition.X;

    for (int i = top - 1; i > 0; --i) {
        GlobalRenderer->CursorPosition.X = originX;
        GlobalRenderer->Print("at 0x");
        GlobalRenderer->Print(to_hstring((uint8_t)i));
        GlobalRenderer->Print(": ");
        GlobalRenderer->PrintNL(stack[i]);
    }

}

// void Stack::Push(const char *functionName)
// {
//     const char *fgdgdfg = functionName;
//     return;
// };
// void Stack::Pop(const char *functionName)
// {
//     const char *jghfgh = functionName;
//     return;
// };
// void Stack::Dump()
// {
//     return;
// };
