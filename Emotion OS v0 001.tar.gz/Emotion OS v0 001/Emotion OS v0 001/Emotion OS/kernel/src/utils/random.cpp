#include "stdint.h"

static unsigned long int next = 1;  // NB: "unsigned long int" is assumed to be 32 bits wide


uint16_t random_r(void)  // RAND_MAX assumed to be 32767
{
    next = next * 1103515245 + 12345;
    return (uint16_t) (next / 65536) % 32768;
}

void srandom_r(unsigned int seed)
{
    next = seed;
}
