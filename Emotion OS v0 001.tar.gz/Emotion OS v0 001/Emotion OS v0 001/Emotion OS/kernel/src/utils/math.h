#pragma once
#include "math.h"

struct Point{
    long X;
    long Y;
};