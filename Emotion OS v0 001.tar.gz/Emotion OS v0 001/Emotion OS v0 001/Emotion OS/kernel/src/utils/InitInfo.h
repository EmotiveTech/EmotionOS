#pragma once

#include "math.h"
#include "Framebuffer.h"
#include "simpleFonts.h"
#include <stdint.h>

// 0xAARRGGBB | Alpha, Red, Green, Blue

class InitInfo {
    public:
        bool KernelInitialized          = false;
        bool BasicRendererInitialized   = false;
        bool MemoryInitialized          = false;
};

extern InitInfo GlobalInitInfo;
