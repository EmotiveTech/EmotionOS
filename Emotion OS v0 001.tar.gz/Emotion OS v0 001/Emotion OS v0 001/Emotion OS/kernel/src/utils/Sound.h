#pragma once

#include <stdint.h>
#include "IO.h"

void beep();
void deathBeep();
static void nosound();
static void play_sound(uint32_t nFrequence);