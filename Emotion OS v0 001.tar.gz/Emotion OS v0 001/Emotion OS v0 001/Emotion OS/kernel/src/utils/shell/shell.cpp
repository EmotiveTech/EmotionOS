#include "shell.h"
#include "../cstr.h"
#include "../userinput/mouse.h"
#include "commands.h"
#include "../panic.h"
#include "../Sound.h"
#include "../paging/PageFrameAllocator.h"
#include "../paging/PageTableManager.h"
#include "../memory.h"
#include "../cstr.h"

Shell *GlobalShell;

// Commands cmds = new Commands();


bool startsWith(uint16_t length, char a[], char b[])
{
    bool endr = true;
    char c[length]; // temp value
    for (uint16_t i = 0; i < length; i++)
    {
        c[i] = a[i];
    }
    return cmpstr(length, c, b);
}

Shell::Shell(Framebuffer *framebuffer)
{
    GlobalRenderer->Color = 0xffffffff;
    GlobalRenderer->PrintNL("InsideOut-OS v1.3.0-alpha | IO-SH v0.2.0");
    GlobalRenderer->PrintNL("Execute 'help' for command list.");
    GlobalRenderer->Print("inside-out> ");
    // GlobalRenderer->Print(to_string(GlobalRenderer->CursorPosition.Y));
    Enabled = true;
    frameBuffer = framebuffer;
}

void Shell::HandleInput(uint8_t keyCode)
{
}

bool cleared = false;
char commandtxt[128];
uint16_t cmd_i = 0;
void Shell::Write(char ascii)
{
    commandtxt[cmd_i] = ascii;
    // add char to char array

    GlobalRenderer->PutChar(ascii);
    cmd_i++;
}

void Shell::Exec()
{
    if (commandtxt[0] == 0)
    {
        FinishCMD();
        return;
    }
    GlobalRenderer->Next();
    // GlobalRenderer->Print(commandtxt);

    // cmds.ExecuteCommand(cmds.GetCommand(commandtxt));

    // if(commandtxt == (char*)"test") {
    //     GlobalRenderer->PrintNL("hey test boy oooooo");
    // } else {
    //     GlobalRenderer->PrintNL("Command not found.");
    // }

    cleared = false;
    // identify command and execute
    if (cmpstr(cmd_i, commandtxt, (char *)"help") && cmd_i == 4)
    {
        GlobalRenderer->PrintNL("Commands:");
        GlobalRenderer->PrintNL("help (Command list)");
        GlobalRenderer->PrintNL("echo \%s (Prints to the console)");
        GlobalRenderer->PrintNL("clear (Clear the screen and redraw necessary components)");
        GlobalRenderer->PrintNL("beep (Makes a beep sound)");
        GlobalRenderer->PrintNL("panic (Panic Screen)");
    }
    else if (startsWith(4, commandtxt, (char *)"echo ")) // needs arguments
    {
        char *ps = commandtxt;
        ps += 4;
        GlobalRenderer->PrintNL(ps);
    }
    else if (cmpstr(cmd_i, commandtxt, (char *)"clear") && cmd_i == 5)
    {
        GlobalRenderer->ClearColor = 0xff000000;
        GlobalRenderer->Clear();
        GlobalRenderer->CursorPosition.Y = 0;
        DrawMouse();
        cleared = true;
    }
    else if (cmpstr(cmd_i, commandtxt, (char *)"panic") && cmd_i == 5)
    {
        GlobalPanic->init("Action made by user in IO-SH");
    }
    else if (cmpstr(cmd_i, commandtxt, (char *)"beep") && cmd_i == 4)
    {
        beep();
    }
    else if (startsWith(3, commandtxt, (char *)"asm "))
    {
        GlobalRenderer->RandomChar();
    }
    else
    {
        GlobalRenderer->PrintNL("Command not found. Execute 'help' for command list.");
    }

    for (int t = 0; t < cmd_i; t++)
    {
        commandtxt[t] = 0;
    }

    cmd_i = 0;

    FinishCMD();
}

void Shell::FinishCMD()
{
    if (!cleared)
        GlobalRenderer->Next();
    else
        cleared = false;
    if ((GlobalRenderer->CursorPosition.Y + 32 + 16) > frameBuffer->Height)
    { // added 32 because of taskbar
        GlobalRenderer->ClearColor = 0xff000000;
        GlobalRenderer->Clear();
        GlobalRenderer->CursorPosition.Y = 0;
        DrawMouse();
    }

    GlobalRenderer->Print("inside-out> ");
    // GlobalRenderer->Print(to_string(GlobalRenderer->CursorPosition.Y));
}