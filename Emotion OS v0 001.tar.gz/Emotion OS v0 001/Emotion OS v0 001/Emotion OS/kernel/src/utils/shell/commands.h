#pragma once
#include "shell.h"

class Commands {
    public:
    void* GetCommand(const char name[]);
};