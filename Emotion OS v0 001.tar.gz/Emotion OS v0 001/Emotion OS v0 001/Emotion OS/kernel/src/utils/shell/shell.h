#pragma once
#include "../BasicRenderer.h"
#include "../Framebuffer.h"

struct Command {
    const char* name;
    void* command;
    uint64_t id;
};

class Shell {
    public:
    Shell(Framebuffer* framebuffer);
    void HandleInput(uint8_t keyCode);
    void Exec();
    void Write(char ascii);
    bool Enabled = false;
    Framebuffer* frameBuffer;

    private:
    void FinishCMD();
};

extern Shell* GlobalShell;