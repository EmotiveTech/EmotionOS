#include "commands.h"

/*void* Test()
{
    return;
}

void* Commands::GetCommand(const char name[])
{
    /*for (int i = 0; i < )
    switch (name)
    {
    case "test":
        /* code */
        /*break;
    
    default:
        break;
    }*/

    /*return Test;
}*/
