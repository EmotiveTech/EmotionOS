#include "panic.h"
#include "BasicRenderer.h"
#include "IO.h"
//#include "scheduling/pit/pit.h"
#include "Sound.h"
#include "cstr.h"
#include "userinput/kbScancodeConverter.h"
#include "debug/Stack.h"

bool keyPressed = false;

void PanicScreen::Reboot()
{
    // for some reason this works but it's not good at all
    // please fix me this is so dumb
    // uint8_t good = 0x02;
    // while (good & 0x02)
    //     good = inb(0x64);
    // outb(0x64, 0xFE);
    //

    asm("hlt"); // i think this one actually works though
}

void PanicScreen::init(const char* panicMessage)
{
    //deathBeep(); // FIXME: this doesnt work
    PanicEnabled = true;
    PanicsTriggered++;
    //PIT::SetDivisor(65535);
    GlobalRenderer->Color = 0xffffffff; // red
    GlobalRenderer->PanicFill(0xffff0000);
    GlobalRenderer->CursorPosition = {512, 0};

    GlobalRenderer->Print("KERNEL PANIC!!! (#");
    GlobalRenderer->Print(to_hstring(PanicsTriggered));
    GlobalRenderer->PrintNL(")");
    GlobalRenderer->PrintNL("A fatal kernel level error has occured and the computer was unable to continue executing programs.");
    GlobalRenderer->Next();
     GlobalRenderer->CursorPosition.X = 512;
    GlobalRenderer->Print("Error type: ");
    GlobalRenderer->Color = 0xffDBDBDB; // light gray
    GlobalRenderer->PrintNL(panicMessage);
    GlobalRenderer->Next();
    GlobalRenderer->Next();
    GlobalRenderer->CursorPosition.X = 512;
    GlobalRenderer->PrintNL("==== STACK DUMP ====");
    GlobalStack.Dump();

    GlobalRenderer->Color = 0xffff2b87; // magenta
    GlobalRenderer->Next();
    GlobalRenderer->Print("SYSTEM HALTED.");
    while(true) {};
    // GlobalRenderer->Print("Press any key to restart..");
    // while(!keyPressed) {
    //     uint8_t scancode = inb(0x60);
    //     if(QWERTYKeyboard::Convert(scancode, false) != 0) {
    //         keyPressed = true;
    //     }
    // }
    // GlobalRenderer->PrintNL(" Restarting..");
    // Reboot();
}

void PanicScreen::PanicHandleKeypress() {
    keyPressed = true;
}
