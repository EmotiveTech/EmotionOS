#include "pci.h"
#include "../ahci/ahci.h"
#include "../memory/heap.h"
#include "../debug/Stack.h"

namespace PCI
{
    void EnumerateFunction(uint64_t deviceAddress, uint64_t function)
    {
        GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
        uint64_t offset = function << 12;
        uint64_t functionAddress = deviceAddress + offset;
        GlobalPTM.MapMemory((void*)functionAddress, (void*)functionAddress);

        PCIDeviceHeader* pciDeviceHeader = (PCIDeviceHeader*)functionAddress;

        if (pciDeviceHeader->DeviceID == 0) return;
        if (pciDeviceHeader->DeviceID == 0xFFFF) return;

        GlobalRenderer->Print(GetVendorName(pciDeviceHeader->VendorID));
        GlobalRenderer->Print(" / ");
        GlobalRenderer->Print(GetDeviceName(pciDeviceHeader->VendorID, pciDeviceHeader->DeviceID));
        GlobalRenderer->Print(" / ");
        GlobalRenderer->Print(DeviceClasses[pciDeviceHeader->Class]);
        GlobalRenderer->Print(" / ");
        GlobalRenderer->Print(GetSubclassName(pciDeviceHeader->Class, pciDeviceHeader->Subclass));
        GlobalRenderer->Print(" / ");
        GlobalRenderer->Print(GetProgIFName(pciDeviceHeader->Class, pciDeviceHeader->Subclass, pciDeviceHeader->ProgIF));

        //GlobalRenderer->Next();

        switch (pciDeviceHeader->Class)
        {
            case 0x01: // mass storage controller
                switch (pciDeviceHeader->Subclass)
                {
                    case 0x06: // Serial ATA
                        switch (pciDeviceHeader->ProgIF)
                        {
                            case 0x01: // AHCI 1.0 device
                                new AHCI::AHCIDriver(pciDeviceHeader);
                        }
                }

        }

        GlobalStack.Pop();
    }


    void EnumerateDevice(uint64_t busAddress, uint64_t device)
    {
        GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);

        // GlobalRenderer->Print("EnumerateDevice(");
        // GlobalRenderer->Print(to_hstring(busAddress));
        // GlobalRenderer->Print(", ");
        // GlobalRenderer->Print(to_hstring(device));
        // GlobalRenderer->PrintNL(");");
        uint64_t offset = device << 15;
        uint64_t deviceAddress = busAddress + offset;
        GlobalPTM.MapMemory((void*)deviceAddress, (void*)deviceAddress);

        GlobalRenderer->PrintNL("hiii!! 2");
        PCIDeviceHeader* pciDeviceHeader = (PCIDeviceHeader*)deviceAddress;
        GlobalRenderer->PrintNL("hiii!! 3");

        if(!pciDeviceHeader) return;
        if (pciDeviceHeader->DeviceID == 0) return;
        if (pciDeviceHeader->DeviceID == 0xFFFF) return;

        GlobalRenderer->PrintNL("uhhhh?");
        for (uint64_t function = 0; function < 8; function++)
        {
            GlobalRenderer->PrintNL("hiii!!?!?!?!");
            EnumerateFunction(deviceAddress, function);
        }

        GlobalStack.Pop();
    }

    void EnumerateBus(uint64_t baseAddress, uint64_t bus)
    {
        GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);

        GlobalRenderer->Print("funny numbers: ");
        GlobalRenderer->Print(to_hstring(baseAddress));
        GlobalRenderer->Print(", bus=");
        GlobalRenderer->PrintNL(to_string(bus));
        GlobalRenderer->Next();
        uint64_t offset = bus << 20; // 0x500000
        GlobalRenderer->Print("offset=");
        GlobalRenderer->PrintNL(to_string(offset));
        uint64_t busAddress = baseAddress + offset;
        GlobalRenderer->Print("bus address=");
        GlobalRenderer->PrintNL(to_hstring(busAddress));
        GlobalPTM.MapMemory((void*)busAddress, (void*)busAddress);

        PCIDeviceHeader* pciDeviceHeader = (PCIDeviceHeader*)busAddress;
        GlobalRenderer->PrintNL(to_hstring((uint64_t)pciDeviceHeader));

        GlobalRenderer->PrintNL(to_hstring(pciDeviceHeader->DeviceID));

        GlobalRenderer->PrintNL(to_hstring(pciDeviceHeader->Status));
        GlobalRenderer->PrintNL(to_hstring(pciDeviceHeader->Command));
        GlobalRenderer->PrintNL(to_hstring(pciDeviceHeader->HeaderType));
        GlobalRenderer->PrintNL("hiii!!");
        GlobalRenderer->PrintNL("hiii!! 22222389ufuisdhj");
        //GlobalRenderer->PrintNL(to_hstring(pciDeviceHeader->DeviceID));

        if (!pciDeviceHeader->DeviceID) {
            GlobalRenderer->PrintNL("I");
            return;
        };
        if (pciDeviceHeader->DeviceID == (uint16_t)0x0000) {
            GlobalRenderer->PrintNL("INVALID DEVICE HEADER!");
            return;
        };
        if (pciDeviceHeader->DeviceID == 0xFFFF) {
            GlobalRenderer->PrintNL("INVALID DEVICE HEADER!");
            return;
        };


        for (uint64_t device = 0; device < 32; device++)
        {
            //EnumerateDevice(busAddress, device);
        }

        GlobalStack.Pop();
    }

    void EnumeratePCI(ACPI::MCFGHeader* mcfg)
    {
        GlobalStack.Push(__PRETTY_FUNCTION__, __LINE__);
        int entries = ((mcfg->Header.Length) - sizeof(ACPI::MCFGHeader)) / sizeof(ACPI::DeviceConfig);
        for (int t = 0; t < entries; t++)
        {
            ACPI::DeviceConfig* newDeviceConfig = (ACPI::DeviceConfig*)((uint64_t)mcfg + sizeof(ACPI::MCFGHeader) + (sizeof(ACPI::DeviceConfig) * t));
            for (uint64_t bus = newDeviceConfig->StartBus; bus < newDeviceConfig->EndBus; bus++)
            {
                GlobalRenderer->Print("hii watch this: ");
                GlobalRenderer->PrintNL(to_hstring(newDeviceConfig->BaseAddress));
                EnumerateBus(newDeviceConfig->BaseAddress, bus);
            }
        }
        GlobalStack.Pop();
    }
}
