#include "stdint.h"

#pragma once

class PanicScreen
{
public:
    void init(const char *panicMessage);

    bool PanicEnabled = false;

    uint8_t PanicsTriggered = 0;

    void PanicHandleKeypress();
    void Reboot();
};

extern PanicScreen* GlobalPanic;
