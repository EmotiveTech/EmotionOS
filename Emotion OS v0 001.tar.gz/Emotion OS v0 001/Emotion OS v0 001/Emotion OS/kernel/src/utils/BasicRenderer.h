#pragma once

#include "math.h"
#include "Framebuffer.h"
#include "simpleFonts.h"
#include <stdint.h>

// 0xAARRGGBB | Alpha, Red, Green, Blue

class BasicRenderer {
    public:
    BasicRenderer(Framebuffer* targetFramebuffer, PSF1_FONT* psf1_Font);

    Framebuffer* TargetFramebuffer;
    PSF1_FONT* PSF1_Font;
    uint32_t MouseCursorBuffer[16 * 16];
    uint32_t MouseCursorBufferAfter[16 * 16];
    Point CursorPosition;
    unsigned int Color;
    unsigned int ClearColor;

    void Print(const char* str); // returns starter cursor pos
    void PrintNL(const char* str);
    //void PrintMany(char* strings[], uint8_t length);
    void PutChar(char chr, unsigned int xOff, unsigned int yOff);
    void PutChar(char chr);
    void ClearChar();

    void Clear();
    void Fill(uint32_t color);
    void FillWithNoise();
    void PanicFill(uint32_t color);
    void Next();
    void DrawOverlayMouseCursor(uint8_t* MouseCursor, Point position, uint32_t color);
    void DrawMouseHex(uint32_t *MouseCursor, Point position);
    void ClearMouseCursor(uint8_t* MouseCursor, Point position, uint32_t *ColorPallete, uint8_t ColorPalleteLength);
    void PutPix(uint32_t x, uint32_t y, uint32_t color);
    uint32_t GetPix(uint32_t x, uint32_t y);
    void PutWindow(uint32_t x, uint32_t y, uint32_t colour, uint32_t textColour, uint32_t width, uint32_t height);
    void RenderTaskbar(uint32_t color, uint32_t textColor, uint32_t height);
    void Draw16b(uint16_t* map, Point pos, uint32_t color, uint32_t otherColor);
    void DrawHex(uint32_t* map, Point position, uint16_t dimensions);
    void RandomChar();
    bool MouseDrawn;
};

extern BasicRenderer* GlobalRenderer;
