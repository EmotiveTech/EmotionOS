#pragma once
#include <stdint.h>

struct Window
{
    uint32_t x;
    uint32_t y;

    uint32_t width;
    uint32_t height;

    uint32_t color;
    uint32_t textColor;
    char *title;
};

class WindowManager
{
public:
    uint32_t windowCount = 0;
    Window windows[];

    void RenderTaskbar(uint32_t color, uint32_t textColor, uint32_t height);
    void NewWindow(uint32_t x, uint32_t y, uint32_t colour, uint32_t textColour, uint32_t width, uint32_t height, char *title);
    void DrawWindow(uint32_t x, uint32_t y, uint32_t color, uint32_t textColor, uint32_t width, uint32_t height, char *title);
    void RedrawWindows();
};

extern WindowManager *GlobalWM;