#include "utils/kernelUtil.h"
//#include "utils/shell/shell.h"
#include "utils/WindowManager.h"
#include "utils/BasicRenderer.h"
#include "utils/InitInfo.h"
#include "utils/scheduling/pit/pit.h"

#include "utils/debug/Stack.h"

// window manager is only used in kernel.cpp
WindowManager *GlobalWM;

// needs to be initialized somewhere, this doesn't make it work yet
PanicScreen *GlobalPanic;

// initialize the stack, although this has severe memory allocation issues
// or maybe im wrong and it's something else
Stack GlobalStack;

InitInfo GlobalInitInfo;


extern "C" void __stack_chk_fail(void) {}

// TODO: fix memory allocation issue with stack.
// it's probably cause of the fact that it defines a const char * upon initialization

// also implement stack push and pop into hopefully all functions of kernel

extern "C" void _start(BootInfo* bootInfo){
    KernelInfo kernelInfo = InitializeKernel(bootInfo);
    GlobalRenderer->PrintNL("==> KERNEL INIT SUCCESS!!!");

    // GlobalShell = new Shell(bootInfo->framebuffer);
    // GlobalRenderer->PrintNL("shell init success");
    //GlobalRenderer->PrintNL(to_string(int64_t(1 + 2)));
    GlobalRenderer->Fill(0xff0000f0);

    PIT::SetDivisor(65535);

    GlobalRenderer->FillWithNoise();

    //PIT::Sleepd(0.5);

    GlobalRenderer->Fill(0xffff0000);

    PIT::Sleepd(1.0);

    GlobalRenderer->Fill(0xff00ff00);

    PIT::Sleepd(1.0);

    GlobalRenderer->Fill(0xff0000ff);

    PIT::Sleepd(1.0);

    GlobalRenderer->Fill(0xff000000);

    //Panic("AutoRestart test");
    GlobalWM->NewWindow(700, 100, 0xff000000, 0xff000000, 500, 500, (char*)"test window hi");
    GlobalWM->RenderTaskbar(0xffffffff, 0xff000000, 32);
    GlobalRenderer->DrawHex(ColorMaps::Logo, {600, 600}, 32); // 16x16 is cursor
    GlobalRenderer->DrawHex(ColorMaps::LogoRed, {570, 600}, 32); // 16x16
    GlobalRenderer->DrawHex(ColorMaps::Forbidden, {600, 600}, 16);
    GlobalWM->NewWindow(150, 150, 0xff000000, 0xff000000, 500, 500, (char*)"Title2");
    GlobalWM->NewWindow(200, 200, 0xff000000, 0xff000000, 500, 500, (char*)"Title3");


    // halt system, avoid rebooting constantly
    while(true)
    {
        asm ("hlt");
    }
}
