bochs -f bochs_config
